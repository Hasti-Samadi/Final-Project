import numpy as np
import matplotlib.pyplot as plt
import os
from scipy.signal import convolve

# تابع ایجاد سیگنال
def create_signal(t):
    signal_1 = np.cos(0.2 * np.pi * t)
    signal_2 = np.cos(0.02 * np.pi * t)
    return signal_1 + signal_2

# تابع فیلتر پایین گذر
def low_pass_filter(size, cutoff):
    t = np.arange(-size // 2, size // 2 + 1)
    h = np.sinc(2 * cutoff * t)
    h *= np.blackman(size + 1)
    h /= np.sum(h)
    return h

# تابع اصلی
def main():
    t = np.linspace(0, 100, 1000)
    signal = create_signal(t)
    
    # ذخیره سیگنال اولیه در فایل متنی
    current_directory = os.path.dirname(os.path.abspath(__file__))
    input_path = os.path.join(current_directory, 'input_signal.txt')
    np.savetxt(input_path, signal)
    
    # خواندن سیگنال از فایل متنی
    signal = np.loadtxt(input_path)
    
    # فیلتر پایین گذر
    lpf = low_pass_filter(51, 0.05)
    
    # جدا کردن سیگنال‌ها
    separated_signal = convolve(signal, lpf, mode='same')
    
    # ذخیره سیگنال فیلتر شده در فایل متنی
    current_directory = os.path.dirname(os.path.abspath(__file__))
    output_path = os.path.join(current_directory, 'filtered_signal.txt')
    np.savetxt(output_path, separated_signal)
    
    plt.figure(figsize=(12, 6))
    plt.plot(t, signal, label='Original Signal')
    plt.plot(t, separated_signal, label='Filtered Signal')
    plt.legend()
    plt.title("Filtered Signal Separation")
    plt.xlabel("Time")
    plt.ylabel("Amplitude")
    plt.show()

if __name__ == "__main__":
    main()
